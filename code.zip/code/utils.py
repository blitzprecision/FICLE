import shutil
import os
def delete_whole_folder(dir):
    os.system('rm -rf '+ dir + '*')
    
def IOU(orig, predicted):
    match = 0
    for i in range(len(orig)):
        orig_split = orig[i].split()
        predicted_split = predicted[i].split()
        if len(orig_split) == 0:
            if len(predicted_split) == 0:
                match += 1
            else:
                match += 0
            continue
        ints = list(set(orig_split) & set(predicted_split))
        match += len(ints)/(len(orig_split)+len(predicted_split)-len(ints))
    return match/len(orig)